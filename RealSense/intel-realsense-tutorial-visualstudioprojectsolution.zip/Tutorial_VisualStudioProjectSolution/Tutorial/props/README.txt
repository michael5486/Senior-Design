Microsoft* Visual Studio* 2010-2013 Integration Property Sheets

Visual Studio 2010-2013 Integration:

. Open property manager in view->PropertyManager. For multiple threaded runtime projects,
  add property sheet VS2010-13.Integration.MT.props to all Debug/Release builds. 
  For multi-threaded DLL runtime projects, add property sheet VS2010-12.Integration.MD.props
  to all Debug/Release builds.

. Build your SDK projects
